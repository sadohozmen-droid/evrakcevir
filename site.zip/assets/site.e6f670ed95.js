(function(){
  var b=document.querySelector('.menu-ac'),m=document.querySelector('.menu');
  if(b&&m)b.addEventListener('click',function(){var a=m.classList.toggle('acik');b.setAttribute('aria-expanded',a)});

  var et=document.querySelector('[data-etiket]');if(!et)return;
  var V=JSON.parse(document.getElementById('etiket-veri').textContent);
  var AY=['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
  var AYU=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
  var sec=et.querySelector('select'),tar=et.querySelector('input[type=month]'),grid=et.querySelector('.delik');
  var o=et.querySelector('[data-o]'),d=et.querySelector('[data-d]'),k=et.querySelector('[data-k]'),s=et.querySelector('[data-s]'),
      kalan=et.querySelector('[data-kalan]'),git=et.querySelector('a.git'),kart=et.querySelector('.etiket');
  V.forEach(function(e){var op=document.createElement('option');op.value=e.id;op.textContent=e.ad;sec.appendChild(op)});
  var n=new Date(),t0=new Date(n.getFullYear(),n.getMonth()-10,1);tar.value=t0.getFullYear()+'-'+String(t0.getMonth()+1).padStart(2,'0');
  grid.innerHTML=AY.map(function(a){return '<i data-a="'+a+'">'+a+'</i>'}).join('');
  function ciz(salla){
    var e=V.filter(function(x){return x.id===sec.value})[0]||V[0];
    var p=(tar.value||'').split('-'),y=+p[0],a=+p[1]-1;if(!y||isNaN(a)){y=n.getFullYear();a=n.getMonth()}
    var t=new Date(y,a+e.ay,1);
    [].forEach.call(grid.children,function(c,i){c.className=i===t.getMonth()?'zimba':''});
    o.textContent=AYU[t.getMonth()]+' '+t.getFullYear();
    var fark=(t.getFullYear()-n.getFullYear())*12+t.getMonth()-n.getMonth();
    kalan.textContent=fark<0?'Süresi '+(-fark)+' ay önce doldu':fark===0?'Bu ay yapılmalı':fark+' ay kaldı';
    kalan.style.color=fark<=1?'var(--kirmizi)':'';
    d.textContent=e.dayanak;
    k.innerHTML=e.kod?('Bu kontrol akreditasyon kapsamımızdadır (Kapsam No <span class="num">'+e.kod+'</span>); raporunuz TÜRKAK akreditasyon markasıyla düzenlenir.'+(e.zorunlu?' <b>'+e.zorunlu+'.</b>':'')):'Bu kontrolü EKİPNET kayıtlı mühendislerimiz yapar ve raporlar.';
    s.textContent='Azami '+e.ay+' ay';
    git.href=e.url;git.textContent=e.ad+' kontrolü hakkında →';
    if(salla){kart.classList.remove('salla');void kart.offsetWidth;kart.classList.add('salla')}
  }
  sec.addEventListener('change',function(){ciz(true)});tar.addEventListener('change',function(){ciz(true)});ciz(false);
})();

(function(){
  var $=function(s,k){return (k||document).querySelector(s)},$$=function(s,k){return [].slice.call((k||document).querySelectorAll(s))};
  /* ---------- Formlar ---------- */
  var params = new URLSearchParams(location.search);
  $$('form[data-form]').forEach(function (f) {
    var durum = $('.form-durum', f), dugme = $('button[type=submit]', f);
    var hizmet = params.get('hizmet'); var hAlan = $('[name=hizmet_on]', f);
    if (hizmet && hAlan) hAlan.value = hizmet.slice(0, 120);
    var tokenAl = function () {
      return fetch('/form/token.php', { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error('token'); return r.json(); })
        .then(function (j) { $('[name=_t]', f).value = j.t; });
    };
    tokenAl().catch(function () {});
    var ilk = Date.now();
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      durum.className = 'form-durum'; durum.textContent = '';
      if (!f.checkValidity()) { f.reportValidity(); return; }
      var cf = $('[name="cf-turnstile-response"]', f);
      if (!cf || !cf.value) { durum.className = 'form-durum hata'; durum.textContent = 'Lütfen güvenlik doğrulamasının tamamlanmasını bekleyin.'; return; }
      dugme.disabled = true; var eski = dugme.textContent; dugme.textContent = 'Gönderiliyor…';
      var gonder = function () {
        return fetch(f.action, { method: 'POST', body: new FormData(f), credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
          .then(function (r) { return r.json().catch(function () { return { ok: false, mesaj: 'Sunucu yanıtı okunamadı.' }; }); });
      };
      (($('[name=_t]', f).value) ? Promise.resolve() : tokenAl()).then(gonder).then(function (j) {
        durum.className = 'form-durum ' + (j.ok ? 'ok' : 'hata');
        durum.textContent = j.mesaj || (j.ok ? 'Gönderildi.' : 'Gönderilemedi.');
        if (j.ok) { f.reset(); if (window.tisgDonusum) window.tisgDonusum(); }
        durum.setAttribute('tabindex', '-1'); durum.focus();
      }).catch(function () {
        durum.className = 'form-durum hata'; durum.textContent = 'Bağlantı hatası. Lütfen 0212 438 52 61 numaralı telefondan bize ulaşın.';
      }).then(function () {
        dugme.disabled = false; dugme.textContent = eski;
        if (window.turnstile) { try { window.turnstile.reset($('.cf-turnstile', f)); } catch (e) {} }
        $('[name=_t]', f).value = ''; tokenAl().catch(function () {});
      });
    });
    void ilk;
  });
})();

/* Google Ads dönüşüm ölçümü — İzin Modu: onay verilmeden çerez yazılmaz */
(function(){
  var AW='AW-10789174403',HEDEF='AW-10789174403/Fq9lCJ6gz7kdEIP51pgo',ANAHTAR='tisg-cerez';
  window.dataLayer=window.dataLayer||[];function gtag(){window.dataLayer.push(arguments)}window.gtag=gtag;
  var izin=null;try{izin=localStorage.getItem(ANAHTAR)}catch(e){}
  gtag('consent','default',{ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied',analytics_storage:'denied',wait_for_update:500});
  if(izin==='evet')gtag('consent','update',{ad_storage:'granted',ad_user_data:'granted'});
  gtag('js',new Date());gtag('config',AW);
  var sc=document.createElement('script');sc.async=true;sc.src='https://www.googletagmanager.com/gtag/js?id='+AW;document.head.appendChild(sc);
  var son=0;function donusum(){var n=Date.now();if(n-son<4000)return;son=n;gtag('event','conversion',{send_to:HEDEF})}
  window.tisgDonusum=donusum;
  document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(!a)return;var h=a.getAttribute('href')||'';if(/^(tel:|mailto:)/i.test(h)||/wa\.me|whatsapp/i.test(h))donusum()},true);
  if(izin)return;
  var b=document.createElement('div');b.className='cerez';b.setAttribute('role','region');b.setAttribute('aria-label','Çerez tercihi');
  b.innerHTML='<p>Reklamlarımızın kaç kişiye ulaştığını ölçmek için Google reklam çerezlerini kullanmak istiyoruz. Onay vermezseniz bu çerezler yazılmaz. <a href="/kvkk-aydinlatma-metni#cerezler">Ayrıntılar</a></p><div><button type="button" class="btn btn-ana" data-c="evet">Kabul Et</button><button type="button" class="btn btn-cizgi" data-c="hayir">Reddet</button></div>';
  b.addEventListener('click',function(e){var c=e.target.getAttribute&&e.target.getAttribute('data-c');if(!c)return;try{localStorage.setItem(ANAHTAR,c)}catch(x){}if(c==='evet')gtag('consent','update',{ad_storage:'granted',ad_user_data:'granted'});b.remove()});
  document.body.appendChild(b);
})();
